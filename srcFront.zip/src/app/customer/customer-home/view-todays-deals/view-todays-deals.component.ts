import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';
import { CutomerViewDealsService } from './cutomer-view-deals.service';
import { ViewAllProductsService } from '../view-all-products/view-all-products.service';
//import { DealsComponent } from 'src/app/seller/seller-home/deals/deals.component';

@Component({
  selector: 'app-view-todays-deals',
  templateUrl: './view-todays-deals.component.html',
  styleUrls: ['./view-todays-deals.component.css']
})
export class ViewTodaysDealsComponent implements OnInit {

  p: number = 0;
  page: boolean = false;
  isProductSelected: boolean = false;
  selectedProduct: Product;
  productOnDeals: SellerDeals[];
  count: number = 0;
  errorMessage: string;
  successMessage: string;
  now = new Date();
  status: number[];
  pageLength:number;
  startDateTime:Date;
  endDateTime:Date;
  

  constructor(private customerViewDealsService: CutomerViewDealsService, private viewAllProductService: ViewAllProductsService) {
    setInterval(() => {
      this.now = new Date();
      this.setStatus();
    }
      , 5000);
  }

  ngOnInit():void {
    this.successMessage = null;
    this.errorMessage = null;
    this.productOnDeals = null;
    this.getProductOnDealsForCustomer();
  }
  

  getProductOnDealsForCustomer() {
    this.status = [],


      this.customerViewDealsService.getProductOnDealsForCustomer(this.p).subscribe
        (
          (response) => {
            
            console.log(response);
            this.viewAllProductService.getAllProducts()
              .subscribe(products => {
                let temp=[]
                for(let i=0; i<products.length;i++){
                  for(let j=0;j<response.length;j++){
                    if(products[i].productId===response[j].productDTO.productId){
                      this.count++;
                      temp.push({
                        dealId: response[j].dealId,
                       
                        // productDTO: products[i],
                        dealDiscount: response[j].dealDiscount,
                        dealStartTime: response[j].startDate,
                        dealEndTime: response[j].endDate,
                        seller: response[j].sellerDTO,
                        errorMessage: response[j].errorMessage,
                        successMessage: response[j].successMessage,
                        productList: products[i]
                      
                        
                      });
                    console.log(response[j].startDate);
                   // this.startDateTime=response[j].startDate;
                    }
                  }
                }
                
                this.productOnDeals=temp;
                this.setStatus();

            // if (this.productOnDeals.length > 10) {
            //   this.page = true;
            // }
              }
              );
            
          },
          (response) => {
            this.errorMessage = <any>response;
            this.productOnDeals = null;
            this.successMessage = null;
          }
        )
  }

  setStatus() {
    let currTime = this.now;
    this.count = 0;
    for (var i = 0; i < this.productOnDeals.length; i++) {
      console.log("ankita", this.productOnDeals[i])
      this.startDateTime = new Date(this.productOnDeals[i].dealStartTime[0],
        this.productOnDeals[i].dealStartTime[1] -1,
        this.productOnDeals[i].dealStartTime[2],
        this.productOnDeals[i].dealStartTime[3],
        this.productOnDeals[i].dealStartTime[4],
        0);
        console.log("new", this.startDateTime)
      this.endDateTime = new Date(this.productOnDeals[i].dealEndTime[0],
        this.productOnDeals[i].dealEndTime[1] - 1,
        this.productOnDeals[i].dealEndTime[2],
        this.productOnDeals[i].dealEndTime[3],
        this.productOnDeals[i].dealEndTime[4],
        0);
        console.log(this.endDateTime)
      

      if (this.startDateTime.getTime() < currTime.getTime() && this.endDateTime.getTime() > currTime.getTime()) {
        this.status[i] = 1;
        this.count++;
      }
      else if (this.startDateTime.getTime() > currTime.getTime()) {
        this.status[i] = 2;
      }
      else if (this.endDateTime.getTime() < currTime.getTime()) {
        this.status[i] = 3;
      }


    }

  }

  setSelectedProduct(product: Product) {
    this.isProductSelected = true;
    this.successMessage = null;
    this.selectedProduct = product;
  }



  unsetSelectedProduct() {
    this.isProductSelected = false;
    this.selectedProduct = null;
  }

}
