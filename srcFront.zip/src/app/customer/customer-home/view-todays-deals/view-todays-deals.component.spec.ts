import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTodaysDealsComponent } from './view-todays-deals.component';

describe('ViewTodaysDealsComponent', () => {
  let component: ViewTodaysDealsComponent;
  let fixture: ComponentFixture<ViewTodaysDealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewTodaysDealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTodaysDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
