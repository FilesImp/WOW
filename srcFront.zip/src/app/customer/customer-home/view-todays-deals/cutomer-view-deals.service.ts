import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CutomerViewDealsService {

  constructor(private http:HttpClient) { 

  }

  getProductOnDealsForCustomer(pageNo:number):Observable<SellerDeals[]>{

    const url=environment.SellerDealAPI + "/customerDealsForToday/"+pageNo;

     return this.http.get<SellerDeals[]>(url)
     .pipe(catchError(this.handleError));
   }

   private handleError(err: HttpErrorResponse) {
    console.log(err)
    let errMsg:string='';
    if (err.error instanceof Error) {   
        errMsg=err.error.message;
        console.log(errMsg)
    }
     else if(typeof err.error === 'string'){
        errMsg=JSON.parse(err.error).message
    }
    else {
       if(err.status==0){ 
           errMsg="No Deals Available";
       }else{
           errMsg=err.error.message;
       }
     }
        return throwError(errMsg);
}
}
