import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-view-deals-for-today',
  templateUrl: './cust-view-deals-for-today.component.html',
  styleUrls: ['./cust-view-deals-for-today.component.css']
})
export class CustViewDealsForTodayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
