import { TestBed } from '@angular/core/testing';

import { CustViewDealsForTodayService } from './cust-view-deals-for-today.service';

describe('CustViewDealsForTodayService', () => {
  let service: CustViewDealsForTodayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustViewDealsForTodayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
