import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustViewDealsForTodayComponent } from './cust-view-deals-for-today.component';

describe('CustViewDealsForTodayComponent', () => {
  let component: CustViewDealsForTodayComponent;
  let fixture: ComponentFixture<CustViewDealsForTodayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustViewDealsForTodayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustViewDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
