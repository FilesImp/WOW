import { Component } from "@angular/core";


@Component({
    selector:"customer-details",
    templateUrl:'./customer-details.component.html'
})
export class CustomerDetailsComponent{
    view: string = 'profile';

}