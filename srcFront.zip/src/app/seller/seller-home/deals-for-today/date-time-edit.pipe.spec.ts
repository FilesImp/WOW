import { DateTimeEditPipe } from './date-time-edit.pipe';

describe('DateTimeEditPipe', () => {
  it('create an instance', () => {
    const pipe = new DateTimeEditPipe();
    expect(pipe).toBeTruthy();
  });
});
