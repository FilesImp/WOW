import { TestBed } from '@angular/core/testing';

import { SellerDealsForTodayService } from './seller-deals-for-today.service';

describe('SellerDealsForTodayService', () => {
  let service: SellerDealsForTodayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellerDealsForTodayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
