import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { Seller } from 'src/app/shared/models/seller';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';
import { DateTimeValidator } from 'src/app/shared/validators/date-time';
import { SellerDealsForTodayService } from '../seller-deals-for-today.service';
@Component({
  selector: 'app-add-deals-for-today',
  templateUrl: './add-deals-for-today.component.html',
  styleUrls: ['./add-deals-for-today.component.css']
})
export class AddDealsForTodayComponent implements OnInit {
  productList: Product[]
  productCategoryList: string[]
  seller: Seller
  displayProducts: Boolean
  product: Product
  successMessage: string
  errorMessage: string
  addProductsToDealForm: FormGroup
  productListLength: boolean=false
  pageNo:number=0
  page: boolean = false
  constructor(private fb: FormBuilder, private SellerDealsForTodayService: SellerDealsForTodayService) { }

  ngOnInit(): void {
    this.displayProducts = true
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.getProductsNotOnDeals()
  }
  getProductsNotOnDeals() {
    console.log(this.seller.emailId)
    this.SellerDealsForTodayService.getProductsNotOnDeals(this.seller.emailId,this.pageNo).subscribe(productList => {
      this.productList = productList
      console.log(productList)
      if (productList.length >= 1) {
        this.productListLength = true
      }
      else{
        this.productListLength=false
      }
    },
    error=>{
      this.errorMessage=error.errorMessage
    })
  }

  showFormToAddDeal(product: Product) {
    this.product = product
    this.displayProducts = false
    this.createForm()
    console.log(this.addProductsToDealForm.value)
  }
  createForm() {
    this.successMessage=this.errorMessage=null
    console.log( this.addProductsToDealForm)
    this.addProductsToDealForm = this.fb.group({
      startDate: ["",[ Validators.required,DateTimeValidator.afterToday]],
      endDate: ["",[ Validators.required,DateTimeValidator.afterToday]],
      dealDiscount: [1, [Validators.required, Validators.min(0.1),Validators.max(100)]],
    },
    {
      validators:[DateTimeValidator.sameDate,DateTimeValidator.endDateValidator]
    });
  }


  addProductToDeals() {
    const deal:SellerDeals = this.addProductsToDealForm.value  as SellerDeals
    deal.productDTO = this.product
    deal.sellerDTO = this.seller
    deal.successMessage=""
    deal.errorMessage=""
    this.SellerDealsForTodayService.addProductToDeal(deal).subscribe(
      response=>{this.successMessage=response.successMessage
        this.displayProducts=true
        this.getProductsNotOnDeals()
      },
       error=>{this.errorMessage=<any>error}
      )
  }

  goToPrevious(){
    if(this.pageNo>0){
      this.pageNo--;
      this.getProductsNotOnDeals();
    }
  }

  goToNext(){
    if(this.productList.length==10){

      this.pageNo++;
      this.getProductsNotOnDeals();
    }
    else{
      this.page = true;
    }
  }
}
