import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDealsForTodayComponent } from './view-deals-for-today.component';

describe('ViewDealsForTodayComponent', () => {
  let component: ViewDealsForTodayComponent;
  let fixture: ComponentFixture<ViewDealsForTodayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewDealsForTodayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
