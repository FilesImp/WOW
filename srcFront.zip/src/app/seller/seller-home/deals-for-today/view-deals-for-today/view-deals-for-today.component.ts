import { Component, OnInit, Input, Inject } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';
import { SellerDealsForTodayService } from '../seller-deals-for-today.service';
import { DOCUMENT } from '@angular/common';
@Component({
  selector: 'app-view-deals-for-today',
  templateUrl: './view-deals-for-today.component.html',
  styleUrls: ['./view-deals-for-today.component.css']
})
export class ViewDealsForTodayComponent implements OnInit {
  seller: Seller;
  successMessage: String="";
  errorMessage: String="";
  product;
  p:number=0;
  page: boolean=false;
  submitted: boolean=false;
  pageLength: any;
  dealList: any[];
  productListLength: boolean=false;

  @Input()
  receiveProduct: Product;
  productsList: Product[];
  productDetails: Product;
  dealProductDetails: SellerDeals;
  displayProducts: Boolean;
  productsInDealList: SellerDeals[];
  productsInDeal: SellerDeals[];
  productsAvailable: boolean;
  constructor(private sellerViewDealProducts: SellerDealsForTodayService,
    @Inject(DOCUMENT) private document:Document) {}

  ngOnInit(): void {
    this.productsList = JSON.parse(sessionStorage.getItem("sellerProducts"));

    this.displayProducts = true;
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.sellerViewDealProducts.getProductsInDealList(this.seller.emailId,0)
      .subscribe(response=>{
      console.log(response)
      this.productsInDealList = response;
      this.displayProducts = this.productsInDealList.length != 0;
      this.page = this.productsInDealList.length != 0;
      this.productsAvailable = this.productsInDealList.length == 0;
    })
    this.getProductsInDealList()
  }
  getProductsInDealList(){
    this.sellerViewDealProducts.getProductsInDealList(this.seller.emailId,this.p)
      .subscribe(response=>{
        console.log(response)
        this.productsInDealList = response;
        this.displayProducts = this.productsInDealList.length != 0;
        this.page = this.productsInDealList.length != 0;

      })
  }
  
  isDealActive(productsInDeal:SellerDeals):boolean{
    let sysDateTime:Date = new Date();
    
    let dealEndsAt:Date = new Date(productsInDeal.endDate[0],productsInDeal.endDate[1]-1,
      productsInDeal.endDate[2],productsInDeal.endDate[3],productsInDeal.endDate[4],0);
    if(dealEndsAt<sysDateTime)
      return false;
    return true;
  }

  viewProductDetails(productId:number){
    console.log(productId)
    console.log(this.productsList)
    this.productDetails = new Product;
    for(let product of this.productsList){
      if(productId == product.productId)
      {
        this.productDetails = product;

      }
      console.log(this.productDetails)
      console.log(this.productsInDealList)
    }
    this.displayProducts = false;
  }

  viewDealProduct(prod:number){
    console.log(prod)
    console.log(this.productsList)
    this.productDetails = new Product;
    for(let product of this.productsList){
      if(prod == product.productId)
      {
        this.productDetails = product;
        console.log(this.productDetails)
      }
    }
  } 

  removeProduct(deal: any){
    console.log(deal)
    let newDeal:SellerDeals=new SellerDeals()
    newDeal.dealId=deal.dealId
    newDeal.dealDiscount=deal.dealDiscount
    newDeal.endDate=null
    newDeal.productDTO=deal.product
    newDeal.startDate=null
    newDeal.sellerDTO=deal.seller
    newDeal.successMessage=""
    newDeal.errorMessage=""
    console.log(newDeal)
    this.document.defaultView.location.reload();
    this.sellerViewDealProducts.removeProduct(newDeal)
    .subscribe(
      response=>{
       this.successMessage=response.successMessage
       
        let newDealList:any[]=[]
        for(let deal1 of this.dealList){

         let endDate1  = deal1.endDate
         let endDateModified = endDate1[0]+"-"+ endDate1[1]+"-"+ endDate1[2] + " "+ endDate1[3]+":"+endDate1[4]
        let todayDate = new Date()
          let endDateFinal=new Date(endDateModified)
        if(todayDate> endDateFinal){
           deal1.isExpired=true
        }
        else{
          deal1.isExpired= false
        }
        if(deal1.dealId!=deal.dealId) {   
         newDealList.push(deal1)}
        }
        this.dealList=newDealList
        console.log(this.dealList)

        if (this.dealList.length > 10) {
          this.page = true
        }
        if(this.dealList.length>=1){
          this.productListLength=true
        }
        else{
          this.productListLength=false
        }
      },
        error=>{
          this.errorMessage=<any>error;
        }
    )}
    
  goToPrevious(){
    if(this.p>0){
      this.p--;
      this.getProductsInDealList();
    }
  }
  goToNext(){
    if(this.productsInDealList.length==10){

      this.p++;
      this.getProductsInDealList();
    }
    else{
      this.page = true;
    }
  }
  
 }


